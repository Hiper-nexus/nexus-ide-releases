# designmd-mcp

MCP server for [DESIGNmd](https://designmd.ai) — search, browse, download, and upload DESIGN.md design systems directly from your AI coding tool.

DESIGN.md files are portable, markdown-based design systems that give AI coding tools the design context they need: colors, typography, spacing, component patterns, and guidelines.

## Setup

A free API key is required to download and view design system content. Searching and browsing work without one. Get your key at [designmd.ai/api-keys](https://designmd.ai/api-keys).

### Claude Code

```bash
claude mcp add -s user designmd -e DESIGNMD_API_KEY=dk_your-key-here -- npx designmd-mcp
```

### Cursor, Windsurf, Antigravity, and others

Add to your MCP config file (`.cursor/mcp.json`, `~/.gemini/antigravity/mcp_config.json`, etc.):

```json
{
  "mcpServers": {
    "designmd": {
      "command": "npx",
      "args": ["designmd-mcp"],
      "env": {
        "DESIGNMD_API_KEY": "dk_your-key-here"
      }
    }
  }
}
```

## Tools

### search_design_kits

Search the DESIGNmd library for design systems.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `query` | string | yes | Search terms (e.g. "dark minimal saas") |
| `tags` | string[] | no | Filter by tag names |
| `sort` | string | no | "trending", "downloads", "likes", "newest" |
| `limit` | number | no | Max results, 1-20 (default: 5) |

### get_design_kit

Get full details and DESIGN.md content of a specific design system. Requires `DESIGNMD_API_KEY`.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `identifier` | string | yes | "username/slug" or full URL |

### download_design_kit

Download a DESIGN.md file and save it to your project. Requires `DESIGNMD_API_KEY`.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `identifier` | string | yes | "username/slug" or full URL |
| `path` | string | no | File path to save to (default: "./DESIGN.md") |

### upload_design_kit

Upload a new DESIGN.md to DESIGNmd. Requires `DESIGNMD_API_KEY`.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `name` | string | yes | Name (max 80 chars) |
| `description` | string | yes | Description (max 500 chars) |
| `content` | string | yes | Full DESIGN.md markdown content |
| `tags` | string[] | no | 1-5 tag names (auto-generated if omitted) |
| `license` | string | no | "mit" (default), "cc0", "cc-by", "cc-by-sa" |

### delete_design_kit

Delete one of your own design systems. Requires `DESIGNMD_API_KEY`.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `identifier` | string | yes | "username/slug" or full URL |

### list_popular_kits

Browse trending and popular design systems.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `tag` | string | no | Filter by a single tag |
| `limit` | number | no | Max results, 1-20 (default: 10) |

### list_tags

List all available tags with usage counts. No parameters.

## Example

```
User: "Find me a dark minimal design system for a SaaS dashboard"

Agent: [calls search_design_kits({ query: "dark minimal saas dashboard" })]

Agent: "I found 3 design systems that match:
        1. 'Midnight SaaS' — 1,420 downloads, dark palette with blue accents
        2. 'Shadow Dashboard' — 890 downloads, dark with purple tones
        3. 'Noir Minimal' — 650 downloads, ultra-minimal dark theme
        Want me to download one?"

User: "Use Midnight SaaS"

Agent: [calls download_design_kit({ identifier: "chef/midnight-saas" })]

Agent: "Done — DESIGN.md saved to your project root."
```

## License

MIT
